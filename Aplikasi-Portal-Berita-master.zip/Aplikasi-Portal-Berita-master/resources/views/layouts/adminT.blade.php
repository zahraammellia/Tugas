			
			<div class="col-2 col-lg-2 col-md-8 mainmenu-admin">
				<div class="col-12 title-menu blue">Admin Menu</div>
				<a href="/home" class="col-12 menu-admin">Visitor <span class="arrow">&rsaquo;</span></a>
				<a href="/daftar" class="col-12 menu-admin">Daftar Artikel  <span class="arrow">&rsaquo;</span></a>
				<a href="/tambah" class="col-12 menu-admin">Tambah Artikel  <span class="arrow">&rsaquo;</span></a>
				<a href="komentar" class="col-12 menu-admin">Daftar Komentar  <span class="arrow">&rsaquo;</span></a>
				<a href="/user" class="col-12 menu-admin">Daftar User  <span class="arrow">&rsaquo;</span></a>
			</div>