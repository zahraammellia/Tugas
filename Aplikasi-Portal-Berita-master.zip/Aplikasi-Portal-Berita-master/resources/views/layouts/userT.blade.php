			<div class="col-2 col-lg-2 col-md-8 mainmenu-admin">
				<div class="col-12 title-menu blue">User Menu</div>
				<a href="/home" class="col-12 menu-admin">Biodata <span class="arrow">&rsaquo;</span> <span class="arrow">&rsaquo;</span></a>
				<a href="/comment" class="col-12 menu-admin">Komentar <span class="arrow">&rsaquo;</span></a>
				<a href="/notification" class="col-12 menu-admin">Pemberitahuan <span class="arrow">&rsaquo;</span></a>
			</div>